import { Link } from "react-router-dom";
import Exchange from "./Exchange";

export default function Textbook() {
  return (
    <div className="App">
      <Exchange />
      <Link to="/">go to home</Link>
    </div>
  );
}
