import { Link } from "react-router-dom";
export default function Exchange() {
  return (
    <>
      <h1>
        exchange your texts books here whether they be digital or physical{" "}
      </h1>

      <h2> history </h2>

      <ul>
        <li>political history</li>
        <li>social history</li>
        <li>economic history</li>
        <li>diplomatic history</li>
        <li>food history</li>
        <li>cultural history</li>
        <li>womens history</li>
        <li>intellectual history</li>
        <li>enviornmental history</li>
      </ul>

      <p>click to see full list of exchangable books</p>
      <p>click here to exchange books</p>

      <h2> science </h2>
      <ul>
        <li>astronomy</li>
        <li>biology</li>
        <li>geology</li>
        <li>chemistry</li>
        <li>palaentology</li>
        <li>botany</li>
        <li>pathology</li>
        <li>zoology</li>
        <li>entomology</li>
        <li>microbiology</li>
      </ul>
      <p>click to see full list of exchangable books</p>
      <p>click here to exchange books</p>

      <h2> art </h2>
      <ul>
        <h3>fine arts</h3>
        <li>graphic design</li>
        <li>sculpture</li>
        <li>print making</li>
        <li>drawing & painting</li>
        <li>studio arts</li>
        <li>archetecture</li>
        <li>digital media</li>
      </ul>
      <h3>film school</h3>
      <ul>
        <li>computer animation</li>
        <li>film & production</li>
        <li>photography</li>
      </ul>
      <p>click to see full list of exchangable books</p>
      <p>click here to exchange books</p>

      <h2>math</h2>
      <ul>
        <li>numerical analysis</li>
        <li>optimization theory</li>
        <li>differential equations</li>
        <li>linear algebra</li>
        <li>calculus</li>
        <li>physics</li>
        <li>computer science</li>
        <li>computational mathematics</li>
        <li>systems design</li>
      </ul>
      <p>click here to exchange books</p>

      <h2>enghlish</h2>
      <ul>
        <li>
          the novel (western,european, modern american, japanese, latin
          american)
        </li>
        <li>compocition</li>
        <li>creative writing</li>
        <li>drama</li>
        <li>english as a second language</li>
        <li>international fiction</li>
        <li>language and linguistics</li>
        <li>language & linguistics</li>
        <li>literary theory & critisism</li>
        <li>poetry</li>
      </ul>
      <p>click to see full list of exchangable books</p>
      <p>click here to exchange books</p>

      <h2>foreign language</h2>
      <ul>
        <li>spanish</li>
        <li>mandarin</li>
        <li>german</li>
        <li>french</li>
      </ul>
    </>
  );
}
