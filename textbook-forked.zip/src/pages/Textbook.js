import { Link } from "react-router-dom";
export default function Textbook() {
  return (
    <div className="App">
      <h1>text book exchange</h1>
      <p>The following images will show the types of exchangeable textbooks</p>
    </div>
  );
}
