import React from "react";
import "./styles.css";
import { BrowserRouter, Routes, Route, Link } from "react-router-dom";
import { HashLink } from "react-router-hash-link";
import textbook from "./pages/Textbook.js";
import history from "./images/history.png";
import science from "./images/science.jpg";
import art from "./images/art.jpg";
import math from "./images/math.png";
import english from "./images/english.jpg";
import foreignlanguage from "./images/foreign language.jpg";
import Exchange from "./pages/Exchange";

// import Foo from "./Foo";

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route
          exact
          path="/"
          element={
            <>
              <h1>text book exchange</h1>
              <img src="/images/history.png" />
              <img src={history} />
              <img src="/images/science.jpg" />
              <img src={science} />
              <img src="/images/art.jpg" />
              <img src={art} />
              <img src="/images/math.png" />
              <img src={math} />
              <img src="/imges/english.jpg" />
              <img src={english} />
              <img src="/images/foriegn language.jpg" />
              <img src={foreignlanguage} />

              <Link to="textbook">Go to exchange page</Link>
            </>
          }
        ></Route>
        <Route exact path="/textbook exchange" element={<textbook />}></Route>
      </Routes>
    </BrowserRouter>
  );
}
