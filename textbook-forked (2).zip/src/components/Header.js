import { HashLink } from "react-router-hash-link";

export default function Head() {
  return (
    <nav>
      <ul>
        <li>
          {" "}
          <HashLink to="/"> Home</HashLink>{" "}
        </li>
        <li>
          {" "}
          <HashLink to="/textbook">textbook</HashLink>{" "}
        </li>
        <li>
          <HashLink to="/history">history</HashLink>
        </li>
        <li>
          <HashLink to="/science">science</HashLink>
        </li>
        <li>
          <HashLink to="/art">art</HashLink>
        </li>
        <li>
          <HashLink to="/math">math</HashLink>
        </li>
        <li>
          <HashLink to="/english">english</HashLink>
        </li>
        <li>
          <HashLink to="/foreignlanguage">languages</HashLink>
        </li>
      </ul>
    </nav>
  );
}
