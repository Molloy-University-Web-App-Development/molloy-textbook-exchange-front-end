import React from "react";
import "./styles.css";
import { BrowserRouter, Routes, Route, Link } from "react-router-dom";
import { HashLink } from "react-router-hash-link";
import Textbook from "./pages/Textbook.js";
import history from "./images/history.png";
import science from "./images/science.jpg";
import art from "./images/art.jpg";
import math from "./images/math.png";
import english from "./images/english.jpg";
import logo from "./images/molloylogo.jpg";
import Foreignlanguage from "./images/foreign language.jpg";
import Exchange from "./pages/Exchange";
import Head from "./components/Header";
import Art_ex from "./pages/ArtExchange";
import Eng_ex from "./pages/EnglishExchange";
import His_ex from "./pages/HistoryExchange";
import Lan_ex from "./pages/LanguageExchange";
import Math_ex from "./pages/MathExchange";
import Sci_ex from "./pages/ScienceExchange";
/*import Navigation from"./components/Header";*/
// import Foo from "./Foo";

export default function App() {
  return (
    <BrowserRouter>
      {<Head />}
      <Routes>
        <Route
          exact
          path="/"
          element={
            <>
              <h1>text book exchange</h1>

              <img src={logo} class="molloy" />

              <Link to="textbook">Go to exchange page</Link>
            </>
          }
        ></Route>
        <Route exact path="/textbook" element={<Textbook />}></Route>
        <Route exact path="/english" element={<Eng_ex />}></Route>
        <Route exact path="/history" element={<His_ex />}></Route>
        <Route exact path="/foreignlanguage" element={<Lan_ex />}></Route>
        <Route exact path="/math" element={<Math_ex />}></Route>
        <Route exact path="/science" element={<Sci_ex />}></Route>
        <Route exact path="/art" element={<Art_ex />}></Route>
      </Routes>
    </BrowserRouter>
  );
}
