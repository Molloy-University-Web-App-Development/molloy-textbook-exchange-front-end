import { HashLink } from "react-router-hash-link";
import sci from "../images/science.jpg";
export default function Sci_ex() {
  return (
    <>
      <h1>welcome to the art textbook page</h1>
      <img src={sci} alt="purple circle with white atom inside" />
    </>
  );
}
