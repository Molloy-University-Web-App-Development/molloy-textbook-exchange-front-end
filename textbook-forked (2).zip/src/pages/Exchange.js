import { Link } from "react-router-dom";

export default function Exchange() {
  return (
    <>
      <h1>textbook exchange</h1>
      <h2>
        exchange your texts books here whether they be digital or physical{" "}
      </h2>
      <h2> history </h2>
      <ul id="his">
        <li>political history</li>
        <li>economic history</li>
        <li>cultural history</li>
        <li>enviornmental history</li>
      </ul>
      <Link to="/his">history book exchange</Link>

      <h2> science </h2>
      <ul id="sci">
        <li>astronomy</li>
        <li>biology</li>
        <li>geology</li>
        <li>chemistry</li>
      </ul>

      <Link to="/sci">science book exchange</Link>
      <h2> art </h2>
      <ul id="art">
        <h3>fine arts</h3>
        <li>graphic design</li>
        <li>sculpture</li>
        <li>print making</li>
        <li>drawing & painting</li>
        <li>studio arts</li>
        <li>archetecture</li>
        <li>digital media</li>
      </ul>
      <h3>film school</h3>
      <ul id="film">
        <li>computer animation</li>
        <li>film & production</li>
        <li>photography</li>
      </ul>

      <Link to="/art">art book exchange</Link>
      <h2>math</h2>
      <ul id="math">
        <li>numerical analysis</li>
        <li>calculus</li>
        <li>physics</li>
        <li>computer science</li>
        <li>computational mathematics</li>
        <li>systems design</li>
      </ul>
      <Link to="/math">math book exchange</Link>
      <h2>english</h2>
      <ul id="eng">
        <li>
          the novel (western,european, modern american, japanese, latin
          american)
        </li>
        <li>compocition</li>
        <li>creative writing</li>
        <li>drama</li>
        <li>english as a second language</li>
        <li>international fiction</li>
        <li>language and linguistics</li>
        <li>language & linguistics</li>
        <li>literary theory & critisism</li>
        <li>poetry</li>
      </ul>

      <Link to="/eng">english book exchange</Link>
      <h2>foreign language</h2>
      <ul id="forlan">
        <li>spanish</li>
        <li>mandarin</li>
        <li>german</li>
        <li>french</li>
        <Link to="/language">foreign language book exchange</Link>
      </ul>
    </>
  );
}
