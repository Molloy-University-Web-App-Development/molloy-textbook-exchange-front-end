import { Link } from "react-router-dom";
import Exchange from "./Exchange";
import Art_ex from "./ArtExchange";
import Eng_ex from "./EnglishExchange";
import His_ex from "./HistoryExchange";
import Lan_ex from "./LanguageExchange";
import Math_ex from "./MathExchange";
import Sci_ex from "./ScienceExchange";
export default function Textbook() {
  return (
    <div className="App">
      <Exchange />

      <Link to="/">go to home</Link>
    </div>
  );
}
