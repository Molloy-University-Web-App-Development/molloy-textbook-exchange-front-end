import { HashLink } from "react-router-hash-link";
import his from "../images/history.png";
export default function His_ex() {
  return (
    <>
      <h1>welcome to the art textbook page</h1>
      <img src={his} alt="big gold h" />
    </>
  );
}
