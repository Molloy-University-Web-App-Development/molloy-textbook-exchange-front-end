import { HashLink } from "react-router-hash-link";
import eng from "../images/english.jpg";
export default function Eng_ex() {
  return (
    <>
      <h1>welcome to the art textbook page</h1>
      <img src={eng} alt="dictionary with brown cover" />
    </>
  );
}
