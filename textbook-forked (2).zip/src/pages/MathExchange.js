import { HashLink } from "react-router-hash-link";
import math from "../images/math.png";
export default function Math_ex() {
  return (
    <>
      <h1>welcome to the art textbook page</h1>
      <img src={math} alt="picture of four basic math operations" />
    </>
  );
}
