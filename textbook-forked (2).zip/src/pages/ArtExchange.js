import { HashLink } from "react-router-hash-link";
import art from "../images/art.jpg";
export default function Art_ex() {
  return (
    <>
      <h1>welcome to the art textbook page</h1>
      <img src={art} alt="bird of colors" />
    </>
  );
}
