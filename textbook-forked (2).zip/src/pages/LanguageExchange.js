import { HashLink } from "react-router-hash-link";
import lan from "../images/foreign language.jpg";
export default function Lan_ex() {
  return (
    <>
      <h1>welcome to the art textbook page</h1>
      <img src={lan} alt="picture of four basic math operations" />
    </>
  );
}
