import { Link } from "react-router-dom";
import { HashLink } from "react-router-hash-link";
import { useEffect } from "react";

export default function About() {
  useEffect(() => {
    window.addEventListener("resize", () => {
      const iw = window.innerWidth;
      console.log("Device Pixel Ratio:", window.devicePixelRatio);
      console.log("Window inner width:", window.innerWidth);
      console.log("80 percent of Window inner width:", 0.8 * window.innerWidth);
      console.log("Image source:", document.querySelector("img").currentSrc);
    });

    document
      .querySelector("img")
      .addEventListener("load", () =>
        console.log("Image source:", document.querySelector("img").currentSrc)
      );
    /*
    // wait 3 seconds to load (3000 ms)
    setTimeout(
      () => console.log(document.querySelector("img").currentSrc),
      3000
    );
    */
  }, []);
  return (
    <>
      <h1 id="top">About something</h1>
      <img
        srcSet="images/seattle_video_high_res.jpg 1200w,
        images/seattle_video_med_res.jpg 600w"
        sizes="(min-width: 1500px) 1200px,
                 80vw"
        alt="scalable"
      />
      <p>
        I don't know what to write here, but maybe you can think of something
        useful to say.
        <svg
          version="1.1"
          width="300"
          height="200"
          xmlns="http://www.w3.org/2000/svg"
        >
          <rect width="100%" height="100%" fill="blue" />

          <circle cx="150" cy="100" r="80" fill="green" />

          <text x="150" y="125" fontSize="60" textAnchor="middle" fill="white">
            SVG
          </text>
        </svg>
      </p>
      <Link to="../#topHeading">Go Back Home</Link>
      <br />
      <HashLink to="#bottom">Go To the bottom</HashLink>
      <h1 style={{ marginTop: "900px" }} id="you">
        You
      </h1>
      <div style={{ marginBottom: "1000px" }}>
        <HashLink smooth to="#top">
          Go back to the Top
        </HashLink>
      </div>
      <div id="bottom">This is the bottom</div>
    </>
  );
}
