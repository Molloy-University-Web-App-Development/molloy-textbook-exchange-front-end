import React from "react";
import "./styles.css";
import { BrowserRouter, Routes, Route, Link } from "react-router-dom";
import { HashLink } from "react-router-hash-link";
import About from "./pages/About";
import myPodWhiteBg from "./assets/mypod-whitebg.jpg";
// import Foo from "./Foo";

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route
          exact
          path="/"
          element={
            <>
              <p>public is root directory here</p>:
              <img src="/images/mypod-whitebg.jpg" />
              <p>Using React import</p>
              <img src={myPodWhiteBg} />
              <h1 id="topHeading">Hello StackBlitz!</h1>
              <p>Start editing to see some magic happen :)</p>
              <Link title="my about page" to="about">
                Go to my About Page
              </Link>
              <br />
              <HashLink to="about#you" smooth>
                Go to the You section of my about page
              </HashLink>
              <div style={{ "margin-bottom": "1000px" }} />
            </>
          }
        ></Route>
        <Route exact path="/about" element={<About />}></Route>
      </Routes>
    </BrowserRouter>
  );
}
